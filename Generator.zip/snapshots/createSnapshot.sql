CREATE DATABASE AKCJE_STRAZY_POZARNEJ_Snapshot2
ON
(
    NAME = AKCJE_STRAZY_POZARNEJ,
    FILENAME = 'C:\Studia\Hurtownie danych\data_generator\snapshots\Snapshot2.ss'
)
AS SNAPSHOT OF AKCJE_STRAZY_POZARNEJ;